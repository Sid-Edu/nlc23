# HANGMAN-GAME
GUI BASED GAME
Game designed by "python tutorials".
for more support visit the youtube channel: https://youtu.be/99zOhml1-6s .
save all the file in same folder and make sure that tkinter module is installed before executing the program.
